/* generated configuration header file - do not edit */
#ifndef R_AGT_CFG_H_
#define R_AGT_CFG_H_
#ifdef __cplusplus
        extern "C" {
        #endif

#define AGT_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#define AGT_CFG_OUTPUT_SUPPORT_ENABLE (1)
#define AGT_CFG_INPUT_SUPPORT_ENABLE (0)

#ifdef __cplusplus
        }
        #endif
#endif /* R_AGT_CFG_H_ */
