/* generated configuration header file - do not edit */
#ifndef BSP_MCU_DEVICE_PN_CFG_H_
#define BSP_MCU_DEVICE_PN_CFG_H_
#define BSP_MCU_R7FA2E2A72DNK
#define BSP_MCU_FEATURE_SET ('A')
#define BSP_ROM_SIZE_BYTES (65536)
#define BSP_RAM_SIZE_BYTES (8192)
#define BSP_DATA_FLASH_SIZE_BYTES (2048)
#define BSP_PACKAGE_QFP
#define BSP_PACKAGE_PINS (24)
#endif /* BSP_MCU_DEVICE_PN_CFG_H_ */
