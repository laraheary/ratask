#ifndef LED_CONTROL_H
#define LED_CONTROL_H

#include "hal_data.h"

// LED States
typedef enum e_led_state {
    LED_STATE_OFF = 0,
    LED_STATE_ON_1,
    LED_STATE_ON_2,
    LED_STATE_TOTAL
} led_state_t;

void led_init(void);
void led_update_state(led_state_t new_state);

#endif // LED_CONTROL_H
