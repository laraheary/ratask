#include "timer_config.h"
#include "led_control.h"

// Declare as a volatile variable to keep track of the current state of the LED
volatile led_state_t g_current_led_state = LED_STATE_OFF;

// This is the callback function for the timer interrupt, It changes the state of the LEDs
void timer_callback(timer_callback_args_t *p_args) {
    if (TIMER_EVENT_CYCLE_END == p_args->event) {
        g_current_led_state++;
        if (g_current_led_state >= LED_STATE_TOTAL) {
            g_current_led_state = LED_STATE_OFF;
        }
        led_update_state(g_current_led_state);
    }
}

// Initialise the timer, This setup is necessary for controlling the LED blinking with precise timing.
void timer_init(void) {
    fsp_err_t err = R_AGT_Open(&g_timer0_ctrl, &g_timer0_cfg);
    if (FSP_SUCCESS == err) {
        err = R_AGT_CallbackSet(&g_timer0_ctrl, timer_callback, NULL, NULL);
    }
    if (FSP_SUCCESS == err) {
        R_AGT_Start(&g_timer0_ctrl);
    }
}
