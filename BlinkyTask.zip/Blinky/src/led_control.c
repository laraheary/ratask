#include "led_control.h"

// Define macros for the pin numbers associated with each LED for easier reference
// This improves code readability and makes it easier to modify pin assignments
#define LED1_PIN BSP_IO_PORT_01_PIN_12
#define LED2_PIN BSP_IO_PORT_09_PIN_14

void led_init(void) {
    // LED-specific Initialisation could go here
}

// This function updates the state of the LEDs based on the provided new_state parameter
void led_update_state(led_state_t new_state) {
    switch (new_state) {
        case LED_STATE_OFF:
            g_ioport.p_api->pinWrite(g_ioport.p_ctrl, LED1_PIN, BSP_IO_LEVEL_LOW);
            g_ioport.p_api->pinWrite(g_ioport.p_ctrl, LED2_PIN, BSP_IO_LEVEL_LOW);
            break;
        case LED_STATE_ON_1:
            g_ioport.p_api->pinWrite(g_ioport.p_ctrl, LED1_PIN, BSP_IO_LEVEL_HIGH);
            g_ioport.p_api->pinWrite(g_ioport.p_ctrl, LED2_PIN, BSP_IO_LEVEL_LOW);
            break;
        case LED_STATE_ON_2:
            g_ioport.p_api->pinWrite(g_ioport.p_ctrl, LED1_PIN, BSP_IO_LEVEL_LOW);
            g_ioport.p_api->pinWrite(g_ioport.p_ctrl, LED2_PIN, BSP_IO_LEVEL_HIGH);
            break;
        default:
            // Handle unexpected state
            break;
    }
}
