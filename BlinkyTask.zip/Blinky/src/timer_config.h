#ifndef TIMER_CONFIG_H
#define TIMER_CONFIG_H

void timer_init(void);

#endif // TIMER_CONFIG_H
